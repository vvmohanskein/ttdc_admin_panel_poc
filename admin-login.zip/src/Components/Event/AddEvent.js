import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import {
  Box,
  CssBaseline,
  Grid,
  TextField,
  Button,
  Typography,
  Paper,
  Avatar,
  Card, 
  CardContent, 
  CardMedia, 
  Divider
} from '@mui/material';
import Sidebar from '../Sidebar';
import AppBarView from '../AppBarView';
import AddLocationIcon from '@mui/icons-material/AddLocation';

import './Event.css';

function AddEvent() {
  const initialValues = {
    placeName: '',
    image: null,
    pdf: null, // Add a field for PDF
    description: '',
  };

  const validationSchema = Yup.object({
    placeName: Yup.string().required('Required'),
    description: Yup.string().required('Required'),
  });

  const handleSubmit = async (values) => {
    const formData = new FormData();
    formData.append('placeName', values.placeName);
    formData.append('description', values.description);
    formData.append('image', values.image);
    formData.append('pdf', values.pdf); // Append PDF to FormData

    for (let [key, value] of formData.entries()) {
      console.log(`${key}: ${value instanceof File ? value.name : value}`);
    }

    try {
      console.log('Payload---->', formData);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleCancel = (resetForm) => {
    resetForm();
    console.log('Form cancelled');
  };

  return (
    <Box sx={{ display: 'flex' }}>
      <CssBaseline />

      {/* Sidebar */}
      <Sidebar />

      {/* Top Bar */}
      <AppBarView />

      {/* Main Content */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          bgcolor: 'background.default',
          p: 3,
          marginTop: 8,
          backgroundImage: 'linear-gradient(135deg, #e3fdf5 0%, #ffe6fa 100%)',
          minHeight: '100vh',
        }}
      >
        <Paper
          elevation={4}
          style={{
            padding: '30px',
            borderRadius: '9px',
            margin: '0 auto',
            backgroundColor: '#ffffff',
          }}
        >
          {/* Add Event Heading */}
          <Box display="flex" alignItems="center" justifyContent="center" mb={5}>
            <Avatar sx={{ bgcolor: '#5f59e4', mr: 1, width: '30px', height: '30px' }}>
              <AddLocationIcon />
            </Avatar>
            <Typography variant="h5" style={{ fontWeight: 600, color: '#3f51b5' }}>
              Add Event
            </Typography>
          </Box>

          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
          >
            {({ setFieldValue, resetForm, values, touched, errors }) => (
              <Form>
                <Grid container spacing={3}>
                  {/* Left Side - Form Fields */}
                  <Grid item xs={12} sm={6}>
                    <Field
                      as={TextField}
                      variant="outlined"
                      margin="normal"
                      required
                      fullWidth
                      label="Place Name"
                      name="placeName"
                      autoFocus
                      error={touched.placeName && Boolean(errors.placeName)}
                      helperText={<ErrorMessage name="placeName" />}
                      InputProps={{
                        style: {
                          borderRadius: '10px',
                          padding: '0px 8px',
                          fontSize: '14px',
                          height: '45px',
                        },
                      }}
                      sx={{ mb: 2 }}
                    />
                    <Field
                      as={TextField}
                      variant="outlined"
                      margin="normal"
                      required
                      fullWidth
                      label="Description"
                      name="description"
                      multiline
                      rows={4}
                      error={touched.description && Boolean(errors.description)}
                      helperText={<ErrorMessage name="description" />}
                      InputProps={{
                        style: {
                          borderRadius: '10px',
                        },
                      }}
                    />
                  </Grid>

                  {/* Right Side - Image and PDF Fields */}
                  <Grid item xs={12} sm={6}>
                    {/* Image Upload */}
                    <input
                      accept="image/*"
                      style={{ display: 'none' }}
                      id="image-upload"
                      type="file"
                      onChange={(event) => {
                        const file = event.currentTarget.files[0];
                        setFieldValue('image', file);
                      }}
                    />
                    <label htmlFor="image-upload">
                      <Button
                        variant="contained"
                        component="span"
                        fullWidth
                        sx={{
                          backgroundColor: '#5f59e4',
                          color: '#fff',
                          mt: 2,
                          borderRadius: '9px',
                          width: '150px',
                          '&:hover': {
                            backgroundColor: '#4038a0',
                          },
                        }}
                      >
                        Upload Image
                      </Button>
                    </label>

                    {values.image && (
                      <Card
                        elevation={4}
                        sx={{
                          mt: 3,
                          borderRadius: '10px',
                          overflow: 'hidden',
                          position: 'relative',
                        }}
                      >
                        <CardContent>
                          <Typography variant="h6" gutterBottom sx={{ fontFamily: 'Montserrat', fontWeight: 'bold', color: '#3f51b5', fontSize: '1.2rem' }}>
                            Preview image:
                          </Typography>
                          <Divider sx={{ mb: 1 }} />

                          <CardMedia
                            className='CardMediaImage'
                            component="img"
                            src={URL.createObjectURL(values.image)}
                            alt="Selected"
                            sx={{
                              maxHeight: '200px',
                              borderRadius: '10px',
                              border: '2px solid #3f51b5',
                              transition: 'transform 0.2s',
                              '&:hover': {
                                transform: 'scale(1.05)',
                              },
                            }}
                          />

                          <Typography variant="body2" mt={1} sx={{ fontFamily: 'Montserrat', fontWeight: 'medium', color: '#555', fontSize: '0.875rem' }}>
                            Selected File: <strong>{values.image ? values.image.name : 'No file selected'}</strong>
                          </Typography>
                        </CardContent>
                      </Card>
                    )}

                    {/* PDF Upload */}
                    <input
                      accept="application/pdf"
                      style={{ display: 'none' }}
                      id="pdf-upload"
                      type="file"
                      onChange={(event) => {
                        const file = event.currentTarget.files[0];
                        setFieldValue('pdf', file);
                      }}
                    />
                    <label htmlFor="pdf-upload" className='PDFLabel'>
                      <Button
                        variant="contained"
                        component="span"
                        fullWidth
                        sx={{
                          backgroundColor: '#5f59e4',
                          color: '#fff',
                          mt: 2,
                          borderRadius: '9px',
                          width: '150px',
                          '&:hover': {
                            backgroundColor: '#4038a0',
                          },
                        }}
                      >
                        Upload PDF
                      </Button>
                    </label>

                    {values.pdf && (
                      <Box mt={1}>
                        <Typography variant="body2" sx={{ fontFamily: 'Montserrat', fontWeight: 'medium', color: '#555', fontSize: '0.875rem' }}>
                          Selected PDF: <strong>{values.pdf.name}</strong>
                        </Typography>
                        <Button
                          variant="outlined"
                          color="primary"
                          href={URL.createObjectURL(values.pdf)} // Create a URL for the PDF
                          target="_blank" // Open in a new tab
                          sx={{ mt: 1 }}
                        >
                          Preview PDF
                        </Button>
                      </Box>
                    )}
                  </Grid>
                </Grid>

                {/* Action Buttons */}
                <Box
                  sx={{
                    mt: 4,
                    display: 'flex',
                    justifyContent: 'flex-end',
                  }}
                >
                  <Button
                    type="button"
                    variant="outlined"
                    color="secondary"
                    onClick={() => handleCancel(resetForm)}
                    sx={{
                      borderRadius: '9px',
                      color: '#d32f2f',
                      height: '35px',
                      borderColor: '#d32f2f',
                      fontFamily: 'Montserrat',
                      '&:hover': {
                        backgroundColor: '#d32f2f',
                        color: '#fff',
                      },
                      mr: 2,
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    variant="contained"
                    sx={{
                      backgroundColor: '#5f59e4',
                      color: '#ffffff',
                      padding: '10px 20px',
                      borderRadius: '9px',
                      height: '35px',
                      fontFamily: 'Montserrat',
                      boxShadow: '0px 4px 20px rgba(95, 89, 228, 0.4)',
                      '&:hover': {
                        backgroundColor: '#4038a0',
                      },
                    }}
                  >
                    Submit
                  </Button>
                </Box>

              </Form>
            )}
          </Formik>
        </Paper>
      </Box>
    </Box>
  );
}

export default AddEvent;
