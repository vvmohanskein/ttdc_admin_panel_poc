import React, { useState } from 'react';
import {
  Box,
  CssBaseline,
  Button,
  Grid,
  Typography,
  Card,
  Paper,
  CardContent,
  CardMedia,
  CardActionArea,
  IconButton,
  Tooltip,
  TextField,
} from '@mui/material';
import { Edit as EditIcon, Delete as DeleteIcon, Search as SearchIcon } from '@mui/icons-material';
import AddIcon from '@mui/icons-material/Add';
import Sidebar from '../Sidebar';
import { Link } from 'react-router-dom';
import AppBarView from '../AppBarView';

const initialCardData = [
  {
    title: 'Card 1',
    image: require('../Logo.png'),
    description: 'This is the description for Card 1.',
  },
  {
    title: 'Card 2',
    image: require('../Logo.png'),
    description: 'This is the description for Card 2.',
  },
  {
    title: 'Card 3',
    image: require('../Logo.png'),
    description: 'This is the description for Card 3.',
  },
  {
    title: 'Card 4',
    image: require('../Logo.png'),
    description: 'This is the description for Card 4.',
  },
  {
    title: 'Card 5',
    image: require('../Logo.png'),
    description: 'This is the description for Card 5.',
  },
];

function Event() {
  const [cards] = useState(initialCardData);
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleEdit = (index) => {
    console.log(`Edit card at index ${index}`);
  };

  const handleDelete = (index) => {
    console.log(`Delete card at index ${index}`);
  };

  return (
    <Box sx={{ display: 'flex' }}>
      <CssBaseline />

      {/* Sidebar */}
      <Sidebar />

      {/* Top Bar */}
      <AppBarView />

      {/* Main Content */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          bgcolor: 'background.default',
          p: 3,
          marginTop: 8,
          backgroundImage: 'linear-gradient(135deg, #e3fdf5 0%, #ffe6fa 100%)',
          minHeight: '100vh',
        }}
      >
        <Paper
          elevation={4}
          sx={{
            padding: '30px',
            borderRadius: '9px',
            margin: '0 auto',
            backgroundColor: '#ffffff',
          }}
        >
          {/* Search Bar & Add Event */}
          <Grid container spacing={2} sx={{ mb: 4 }}>
            <Grid item xs={12} md={8}>
              <TextField
                size="small"
                variant="outlined"
                placeholder="Search events..."
                value={searchTerm}
                onChange={handleSearchChange}
                InputProps={{
                  startAdornment: (
                    <IconButton>
                      <SearchIcon />
                    </IconButton>
                  ),
                }}
                sx={{
                  flexGrow: 1,
                  marginRight: 2,
                }}
              />
            </Grid>
            <Grid item xs={12} md={4} sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <Link to="/admin/AddEvent" style={{ textDecoration: 'none' }}>
                <Button
                  variant="contained"
                  startIcon={<AddIcon />}
                  sx={{
                    bgcolor: '#5f59e4',
                    color: 'white',
                    '&:hover': {
                      bgcolor: '#706aff',
                    },
                    borderRadius: '8px', // Rounded corners for a modern look
                    padding: '4px 12px', // Reduced padding
                    fontWeight: 'bold',
                    fontSize: '0.875rem', // Smaller font size
                    boxShadow: '0 4px 10px rgba(0, 0, 0, 0.2)', // Subtle shadow
                    transition: 'background-color 0.3s ease', // Smooth transition
                  }}
                >
                  Add Event
                </Button>
              </Link>
            </Grid>
          </Grid>

          {/* Product List Section */}
          <Grid container spacing={2}>
            {cards.map((card, index) => (
              <Grid item xs={12} sm={6} md={4} key={index}>
<Card
  sx={{
    height: '400px',
    boxShadow: '0 8px 20px rgba(0, 0, 0, 0.15)',
    overflow: 'hidden',
    position: 'relative',
    transition: 'transform 0.3s ease, box-shadow 0.3s ease',
    display: 'flex', // Added to make it a flex container
    flexDirection: 'column', // Column direction
  }}
>
  <CardActionArea sx={{ flexGrow: 1 }}> {/* Allow this area to grow */}
    <Box sx={{ height: '160px', overflow: 'hidden' }}>
      <CardMedia
        component="img"
        alt={card.title}
        height="100%"
        image={card.image}
        sx={{
          objectFit: 'cover',
          borderRadius: '8px',
          transition: 'opacity 0.3s ease',
          '&:hover': {
            opacity: 0.85,
          },
        }}
      />
    </Box>
  </CardActionArea>
  
  {/* Adjusted CardContent */}
  <CardContent
    sx={{
      flexGrow: 0, // Ensure it doesn't grow beyond its content
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      height: '80px', // Fixed height to keep it uniform
    }}
  >
    <Typography
      gutterBottom
      variant="h6"
      component="h2"
      sx={{
        color: '#333',
        fontWeight: 'bold',
        fontSize: '1.2rem',
      }}
    >
      {card.title}
    </Typography>
    <Typography
      variant="body2"
      color="textSecondary"
      component="p"
      sx={{
        color: '#757575',
        fontStyle: 'italic',
      }}
    >
      {card.description}
    </Typography>
  </CardContent>

  {/* Edit and Delete Buttons */}
  <Box
    sx={{
      position: 'absolute',
      top: 8,
      right: 8,
      display: 'flex',
      gap: '4px',
    }}
  >
    <Tooltip title="Edit" arrow>
      <IconButton
        aria-label="edit"
        onClick={() => handleEdit(index)}
        sx={{
          bgcolor: '#ffffff',
          padding: '4px',
          boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
          '&:hover': {
            bgcolor: '#e0e0e0',
          },
        }}
      >
        <EditIcon fontSize="small" />
      </IconButton>
    </Tooltip>
    <Tooltip title="Delete" arrow>
      <IconButton
        aria-label="delete"
        onClick={() => handleDelete(index)}
        sx={{
          bgcolor: '#ffffff',
          padding: '4px',
          boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
          '&:hover': {
            bgcolor: '#e57373',
          },
        }}
      >
        <DeleteIcon fontSize="small" />
      </IconButton>
    </Tooltip>
  </Box>
</Card>


              </Grid>
            ))}
          </Grid>
        </Paper>
      </Box>
    </Box>
  );
}

export default Event;
